#include "UnixEpochToDate.h"

int UnixEpochToDate::setUnixEpoch(unsigned long t)
{
  last_epoch = t;
  t += _timeOffset;
  unsigned long days, secs;
  long remdays, remsecs, remyears;
  long qc_cycles, c_cycles, q_cycles;
  long years, months;
  long wday, yday, leap;
  static const char days_in_month[] = {31,30,31,30,31,31,30,31,30,31,31,29};
  //static const char days_in_month[] = {31,29,30,31,30,31,30,31,30,31,30};

  secs = t - LEAPOCH;
  days = secs / 86400;
  remsecs = secs % 86400;
  if (remsecs < 0) {
    remsecs += 86400;
    days--;
  }

  wday = (3+days)%7;
  if (wday < 0) wday += 7;

  qc_cycles = days / DAYS_PER_400Y;
  remdays = days % DAYS_PER_400Y;
  if (remdays < 0) {
    remdays += DAYS_PER_400Y;
    qc_cycles--;
  }

  c_cycles = remdays / DAYS_PER_100Y;
  if (c_cycles == 4) c_cycles--;
  remdays -= c_cycles * DAYS_PER_100Y;

  q_cycles = remdays / DAYS_PER_4Y;
  if (q_cycles == 25) q_cycles--;
  remdays -= q_cycles * DAYS_PER_4Y;

  remyears = remdays / 365;
  if (remyears == 4) remyears--;
  remdays -= remyears * 365;

  leap = !remyears && (q_cycles || !c_cycles);
  yday = remdays + 31 + 28 + leap;
  if (yday >= 365+leap) yday -= 365+leap;

  years = remyears + 4*q_cycles + 100*c_cycles + 400*qc_cycles;

  for (months=0; days_in_month[months] <= remdays; months++)
    remdays -= days_in_month[months];

  if (years+100 > _INT_MAX || years+100 < _INT_MIN)
    return -2;

  ts.years = years; //+ 100;
  ts.months = months + 3;
  if (ts.months > 12) {
    ts.months -= 12;
    ts.years++;
  }
  
  ts.days = remdays + 1;
  ts.dayOfWeek = wday + 1;
  ts.dayOfYear = yday + 1;

  ts.hours = remsecs / 3600;
  ts.minutes = remsecs / 60 % 60;
  ts.seconds = remsecs % 60;

  return 1;
}

unsigned long UnixEpochToDate::getEpochTime() 
{
  return this->_timeOffset + this->last_epoch; // Epoc returned by the NTP server
}

int UnixEpochToDate::getYear()
{

  return ts.years;
}

int UnixEpochToDate::getDayOfYear()
{

  return ts.dayOfYear;
}

int UnixEpochToDate::getDayOfWeek()
{

  return ts.dayOfWeek;
}

int UnixEpochToDate::getMonth()
{

  return ts.months;
}

int UnixEpochToDate::getDay() 
{
   return ts.days;
}

int UnixEpochToDate::getHours() 
{
  return ts.hours;
}

int UnixEpochToDate::getMinutes() 
{
  return ts.minutes;
}

int UnixEpochToDate::getSeconds() 
{
  return ts.seconds;
}

String UnixEpochToDate::getFormattedDate() 
{
  int _year = ts.years;
  String yearStr = _year < 10 ? "0" + String(_year) : String(_year);

  int _month = ts.months;
  String monthStr = _month < 10 ? "0" + String(_month) : String(_month);

  int _day = ts.days;
  String dayStr = _day < 10 ? "0" + String(_day) : String(_day);
  
  return yearStr + "." + monthStr + "." + dayStr;
  
}

String UnixEpochToDate::getFormattedDateShort() 
{
  int _month = ts.months;
  String monthStr = _month < 10 ? "0" + String(_month) : String(_month);

  int _day = ts.days;
  String dayStr = _day < 10 ? "0" + String(_day) : String(_day);
 
  return monthStr + "." + dayStr;
  
}

String UnixEpochToDate::getFormattedTime() {

  int hours = ts.hours;
  String hoursStr = hours < 10 ? "0" + String(hours) : String(hours);

  int minutes = ts.minutes;
  String minuteStr = minutes < 10 ? "0" + String(minutes) : String(minutes);

  int seconds = ts.seconds;
  String secondStr = seconds < 10 ? "0" + String(seconds) : String(seconds);

  return hoursStr + ":" + minuteStr + ":" + secondStr;
}

String UnixEpochToDate::getFormattedTimeShort() {

  int hours = ts.hours;
  String hoursStr = hours < 10 ? "0" + String(hours) : String(hours);

  int minutes = ts.minutes;
  String minuteStr = minutes < 10 ? "0" + String(minutes) : String(minutes);

  return hoursStr + ":" + minuteStr;
}

void UnixEpochToDate::setTimeOffset(int timeOffset) {
  _timeOffset     = timeOffset * 3600;
}


