#pragma once

#include "Arduino.h"

#include <Udp.h>

#define SEVENZYYEARS 2208988800UL
#define NTP_PACKET_SIZE 48
#define NTP_DEFAULT_LOCAL_PORT 1337

//-------------------------------------------------------------------
// extension
#define _INT_MAX 32767
#define _INT_MIN -32768
#define LEAPOCH (946684800LL + 86400*(31+29))
#define DAYS_PER_400Y (365*400 + 97)
#define DAYS_PER_100Y (365*100 + 24)
#define DAYS_PER_4Y   (365*4   + 1)

#define WITH_YEAR 0
#define WITHOUT_YEAR 1

// end extension
//--------------------------------------------------------------------


class UnixEpochToDate {
  private:
    
    int           _timeOffset     = 0;
    unsigned long last_epoch = 0;
    // added functions
	typedef struct TimeStruct 
    {
	    int seconds;
	    int minutes;
	    int hours;
	    int days;
	    int dayOfWeek;
	    int dayOfYear;
	    int months;
	    int years;
    }TimeStruct;
	
	TimeStruct ts;
	
	
	
  public:
  
    int setUnixEpoch(unsigned long t);
	int getYear();      //added
	int getMonth();     //added
	int getDay();       //modified
    int getHours();     //modified
    int getMinutes();   //modified
    int getSeconds();   //modified
	int getDayOfWeek(); //added
	int getDayOfYear(); //added

    void setTimeOffset(int timeOffset);

/**
     * @return time formatted like `hh:mm:ss`
     */
    String getFormattedTime();
	
	String getFormattedTimeShort();
	
	String getFormattedDate();
	
	String getFormattedDateShort();

    unsigned long getEpochTime();

};
